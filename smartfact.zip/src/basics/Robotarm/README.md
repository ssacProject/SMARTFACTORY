# Robotarm

3월 30일
- jetson nano servo test 마침

3월 31일
- 좌표에 따른 위치 이동 interface 작성
- ros 연동

sympy tutorial
http://allman84.blogspot.com/2018/10/sympy.html

inverse kinetics
https://ddangeun.tistory.com/27

data frame
https://3months.tistory.com/292

numpy
https://bskyvision.com/827
