# Simple demo of of the PCA9685 PWM servo/LED controller library.
# This will move channel 0 from min to max position repeatedly.
# Author: Tony DiCola
# License: Public Domain
from __future__ import division
import time

# Import the PCA9685 module.
import Adafruit_PCA9685


# Uncomment to enable debug output.
#import logging
#logging.basicConfig(level=logging.DEBUG)

# Initialise the PCA9685 using the default address (0x40).
pwm = Adafruit_PCA9685.PCA9685()

# Alternatively specify a different address and/or bus:
#pwm = Adafruit_PCA9685.PCA9685(address=0x41, busnum=2)

# Configure min and max servo pulse lengths

#dong think 100 is servo_min, 650 is max.
#pulse legth 100 -> 0 degree, pulse length 650 -> 180 degree
#650-100=550, 55 pulse length -> 18 degree

eighteen_degree = 55
eighteen_degree_onefifth = 11


servo_min = 100  # Min pulse length out of 4096
servo_max = 650  # Max pulse length out of 4096

# Helper function to make setting a servo pulse width simpler.
def set_servo_pulse(channel, pulse):
    pulse_length = 1000000    # 1,000,000 us per second
    pulse_length //= 60       # 60 Hz
    print('{0}us per period'.format(pulse_length))
    pulse_length //= 4096     # 12 bits of resolution
    print('{0}us per bit'.format(pulse_length))
    pulse *= 1000
    pulse //= pulse_length
    pwm.set_pwm(channel, 0, pulse)

# Set frequency to 60hz, good for servos.
pwm.set_pwm_freq(60)

print('Moving servo on channel 11, press Ctrl-C to quit...')
# Move servo on channel 11 between extremes.

#default
#4th motor
#initial point
pwm.set_pwm(4, 0, servo_min + eighteen_degree*4)

#3rd motor

for i in range(32):
    pwm.set_pwm(3, 0, servo_min + eighteen_degree_onefifth*7 +i)
    time.sleep(0.01)

#goal point
pwm.set_pwm(3, 0, servo_min + eighteen_degree_onefifth*10)

for i in range(32):
    pwm.set_pwm(3, 0, servo_min + eighteen_degree_onefifth*10 -i)
    time.sleep(0.01)

#initial point
pwm.set_pwm(3, 0, servo_min + eighteen_degree_onefifth*7)
time.sleep(0.5)


#1st motor

#initial point
pwm.set_pwm(1, 0, servo_min + eighteen_degree*1)

for i in range(54):
    pwm.set_pwm(1, 0, servo_min + eighteen_degree*1 +i)
    time.sleep(0.01)

#goal point
pwm.set_pwm(1, 0, servo_min + eighteen_degree*2)

for j in range(54):
    pwm.set_pwm(1, 0, servo_min + eighteen_degree*2 -j)
    time.sleep(0.01)


###Claws open###6th motor
pwm.set_pwm(6, 0, servo_min + eighteen_degree*0)
time.sleep(0.5)

#2nd motor

#initial point
pwm.set_pwm(2, 0, servo_min + eighteen_degree*1)

for i in range(100):
    pwm.set_pwm(2, 0, servo_min + eighteen_degree*1 +i)
    time.sleep(0.005)
time.sleep(0.3)
#goal point
#pwm.set_pwm(2, 0, servo_min + eighteen_degree*3)


###Claws close### 6th motor
pwm.set_pwm(6, 0, servo_min + eighteen_degree_onefifth*8)
#--------#
time.sleep(0.5)

###Lift###
for j in range(100):
    pwm.set_pwm(2, 0, servo_min + eighteen_degree*1+100 -j)
    time.sleep(0.005)
time.sleep(0.5)



'''
for j in range(55):
    pwm.set_pwm(4, 0, servo_min + eighteen_degree*5 -j)
    time.sleep(0.01)

#goal point
pwm.set_pwm(4, 0, servo_min + eighteen_degree*4)

for j in range(55):
    pwm.set_pwm(4, 0, servo_min + eighteen_degree*4 +j)
    time.sleep(0.01)
'''




#5th motor

#intial point
pwm.set_pwm(5, 0, servo_min + eighteen_degree*5)
time.sleep(1)

#goal point
pwm.set_pwm(5, 0, servo_min + eighteen_degree*2)
time.sleep(1)

pwm.set_pwm(5, 0, servo_min + eighteen_degree*5)
time.sleep(1)


#default
#4th motor

#initial point
pwm.set_pwm(4, 0, servo_min + eighteen_degree*5)
