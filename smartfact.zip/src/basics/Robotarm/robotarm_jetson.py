# SDA = pin.SDA_1
# SCL = pin.SCL_1
# SDA_1 = pin.SDA
# SCL_1 = pin.SCL

from adafruit_servokit import ServoKit
import board
import busio
import time
#from approxeng.input.selectbinder import ControllerResource


# On the Jetson Nano
# Bus 0 (pins 28,27) is board SCL_1, SDA_1 in the jetson board definition file
# Bus 1 (pins 5, 3) is board SCL, SDA in the jetson definition file
# Default is to Bus 1; We are using Bus 0, so we need to construct the busio first ...

print("Initializing Servos")
i2c_bus1=(busio.I2C(board.SCL, board.SDA))

print("Initializing ServoKit")
kit = ServoKit(channels=16)

# kit[0] is the bottom servo
# kit[1] is the top servo

print("Done initializing")


servo_angle_min = 0  # Min pulse length out of 4096
servo_angle_max = 180  # Max pulse length out of 4096


#3rd motor
init_angle_3rd = 50
goal_angle_3rd = 65

#1st motor
init_angle_1st = 30 
goal_angle_1st = 180
break_angle_1st = 50

#2nd motor
init_angle_2nd = 40
goal_angle_2nd = 0


#6th motor
init_angle_6th = 40
goal_angle_6th = 0


#5th motor
init_angle_5th = 90
goal_angle_5th = 36






#------1st motor_init to goal--------#
for sweep in range(break_angle_1st-init_angle_1st):
    kit.servo[1].angle=init_angle_1st + sweep
    time.sleep(0.02)

'''
#------1st motor_init --------#
kit.servo[1].angle = init_angle_1st
'''

#-------Claws open_6th motor---------#
kit.servo[6].angle=goal_angle_6th


#------3rd motor_init to goal--------#
for sweep in range(goal_angle_3rd-init_angle_3rd):
    kit.servo[3].angle=init_angle_3rd + sweep
    time.sleep(0.01)
#------2nd motor_goal to init--------#
for sweep in range(init_angle_2nd -goal_angle_2nd):
    kit.servo[2].angle=goal_angle_2nd + sweep
    time.sleep(0.01)
time.sleep(0.5)




#-------Claws close_6th motor---------#
kit.servo[6].angle=init_angle_6th
time.sleep(0.5)


#------2nd motor_init to goal--------#
for sweep in range(init_angle_2nd -goal_angle_2nd):
    kit.servo[2].angle=init_angle_2nd - sweep
    time.sleep(0.01)


#------1st motor_break to goal--------#
for sweep in range(goal_angle_1st-break_angle_1st):
    kit.servo[1].angle=break_angle_1st + sweep
    time.sleep(0.02)


#------2nd motor_goal to init--------#
for sweep in range(init_angle_2nd -goal_angle_2nd):
    kit.servo[2].angle=goal_angle_2nd + sweep
    time.sleep(0.01)
time.sleep(0.5)


#-------Claws open_6th motor---------#
kit.servo[6].angle=goal_angle_6th
time.sleep(0.5)


#------2nd motor_init to goal--------#
for sweep in range(init_angle_2nd -goal_angle_2nd):
    kit.servo[2].angle=init_angle_2nd - sweep
    time.sleep(0.01)
time.sleep(0.5)

#-------Claws close_6th motor---------#
kit.servo[6].angle=init_angle_6th


#------1st motor_goal to init--------#
for sweep in range(goal_angle_1st-init_angle_1st):
    kit.servo[1].angle=goal_angle_1st - sweep
    time.sleep(0.02)

#------3rd motor_goal to init--------#
for sweep in range(goal_angle_3rd-init_angle_3rd):
    kit.servo[3].angle=goal_angle_3rd-sweep
    time.sleep(0.01)

'''
#5th motor

#intial point
kit.servo[5].angle=init_angle_5th
time.sleep(1)

#goal point
kit.servo[5].angle=goal_angle_5th
time.sleep(1)

kit.servo[5].angle=init_angle_5th
time.sleep(1)
'''

'''
#default
#------4th motor--------#
kit.servo[4].angle=72

#------4th motor--------#
for sweep in range(55):
    pwm.set_pwm(4, 0, servo_min + eighteen_degree*5 -j)
    time.sleep(0.01)

#goal point
pwm.set_pwm(4, 0, servo_min + eighteen_degree*4)

for sweep in range(55):
    pwm.set_pwm(4, 0, servo_min + eighteen_degree*4 +j)
    time.sleep(0.01)


'''
